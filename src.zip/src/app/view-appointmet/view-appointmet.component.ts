import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-appointmet',
  templateUrl: './view-appointmet.component.html',
  styleUrls: ['./view-appointmet.component.css']
})
export class ViewAppointmetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
