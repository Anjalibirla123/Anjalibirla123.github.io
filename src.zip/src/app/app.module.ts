import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppComponent } from "./app.component";
import { LandingPageComponent } from "./landing-page/landing-page.component";
import { PlaceFitnessTesterComponent } from "./place-fitness-tester/place-fitness-tester.component";
import { ViewAppointmetComponent } from "./view-appointmet/view-appointmet.component";
import { SearchComponent } from "./search/search.component";
import { ContactUsComponent } from "./contact-us/contact-us.component";
import { MyRouteModule } from "./my-route/my-route.module";
import { RouterModule } from "@angular/router";

@NgModule({
  declarations: [
    AppComponent,
    LandingPageComponent,
    PlaceFitnessTesterComponent,
    ViewAppointmetComponent,
    SearchComponent,
    ContactUsComponent,
  ],
  imports: [
    BrowserModule, 
    MyRouteModule, 
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
