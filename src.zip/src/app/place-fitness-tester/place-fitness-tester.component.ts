import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-place-fitness-tester',
  templateUrl: './place-fitness-tester.component.html',
  styleUrls: ['./place-fitness-tester.component.css']
})
export class PlaceFitnessTesterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
